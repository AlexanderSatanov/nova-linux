# Installation status

There is currently no installable Redmi 8 firmware artifact.

The ext4 image is a root filesystem for development/testing and must not be flashed directly.
A device installation requires a verified kernel/DTB, boot image packaging, rootfs handoff,
partition layout, bootloader unlock procedure, and recovery plan. Bootloader unlocking may erase
user data. Back up the device and follow current official/vendor and device-community documentation.
