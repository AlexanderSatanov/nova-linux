# Hardware support matrix

All entries below are unverified by this project until tested on physical Redmi 8 hardware.

| Component | Status | Notes |
|---|---|---|
| ARM64 userspace | Build target | Rootfs only |
| Kernel | Not integrated | Must source compatible `olive` kernel |
| Device Tree | Not integrated | Must match exact board/variant |
| Display/touch | Unverified | Depends on kernel and userspace stack |
| Wi-Fi/Bluetooth | Unverified | Firmware and drivers may be needed |
| Audio | Unverified | SoC routing and codecs need integration |
| Battery/charging | Unverified | Requires power-supply drivers |
| Cellular modem | Unverified | Modem interface/RIL integration uncertain |
| Cameras | Unverified | Often requires proprietary vendor components |
| Suspend/resume | Unverified | Device-specific validation needed |
