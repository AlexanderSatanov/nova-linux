# Boot architecture

The project currently creates only a Debian ARM64 root filesystem image. It does not produce
a bootable phone image. The Redmi 8 boot chain must be researched independently: bootloader
state, Android boot image header version, kernel command line, DTB placement, initramfs strategy,
rootfs location, firmware dependencies, and partition map. Any future packaging step must validate
all inputs and produce files only; flashing remains a separate manual, opt-in operation.
