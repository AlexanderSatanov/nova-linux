# Troubleshooting

- `debootstrap` fails: verify internet access, mirror reachability, suite availability, and free disk.
- ARM64 second stage fails on amd64: install `qemu-user-static` and `binfmt-support`; confirm
  `qemu-aarch64` binfmt registration.
- Phosh package unavailable: inspect APT errors and package availability for Debian Trixie ARM64.
  Do not claim the UI is installed if apt failed.
- ext4 image fails: check disk space and permissions; the script removes a partial image on failure.
- Build rerun blocked: inspect `nova-output` first; use `make clean` only if you intend to delete it.
- Phone does not boot: no phone boot image is currently generated; do not flash the ext4 image.
