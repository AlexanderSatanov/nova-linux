# Build guide

1. Use a clean Ubuntu/Debian build host with 12 GiB or more free disk.
2. Run `make deps`.
3. Run `make rootfs`; this downloads Debian packages and requires network access.
4. Run `make configure`; it installs packages listed in `config/packages.list`.
5. Run `make image`; output is an ext4 root filesystem, not a phone firmware.
6. Run `make test`.

If the mobile package list cannot be resolved by the selected Debian suite/architecture, inspect
`nova-output/logs/configure.log`, verify package availability, and update the package list explicitly.
Do not suppress package installation errors.
