#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
require_root
[[ -d "$NOVA_ROOTFS/etc" ]] || die "Rootfs missing; run make rootfs first."
LOG_FILE="$NOVA_LOG_DIR/configure.log"
mounted=()
cleanup() {
  for ((i=${#mounted[@]}-1; i>=0; i--)); do umount "${mounted[$i]}" 2>/dev/null || true; done
}
trap cleanup EXIT
mount -t proc proc "$NOVA_ROOTFS/proc"; mounted+=("$NOVA_ROOTFS/proc")
mount --bind /dev "$NOVA_ROOTFS/dev"; mounted+=("$NOVA_ROOTFS/dev")
mount --bind /dev/pts "$NOVA_ROOTFS/dev/pts"; mounted+=("$NOVA_ROOTFS/dev/pts")
mount -t sysfs sysfs "$NOVA_ROOTFS/sys"; mounted+=("$NOVA_ROOTFS/sys")
install -D -m 0644 "$NOVA_PROJECT_DIR/rootfs/overlays/etc/os-release" "$NOVA_ROOTFS/etc/os-release"
printf '%s\n' "$NOVA_HOSTNAME" > "$NOVA_ROOTFS/etc/hostname"
cat > "$NOVA_ROOTFS/etc/hosts" <<EOF
127.0.0.1 localhost
127.0.1.1 ${NOVA_HOSTNAME}
::1 localhost ip6-localhost ip6-loopback
EOF
cat > "$NOVA_ROOTFS/etc/apt/sources.list" <<EOF
deb ${DEBIAN_MIRROR} ${DEBIAN_SUITE} main
deb ${DEBIAN_MIRROR} ${DEBIAN_SUITE}-updates main
deb https://security.debian.org/debian-security ${DEBIAN_SUITE}-security main
EOF
rm -f "$NOVA_ROOTFS/etc/apt/sources.list.d/debian.sources"
printf 'LANG=en_US.UTF-8\n' > "$NOVA_ROOTFS/etc/locale.conf"
printf 'UTC\n' > "$NOVA_ROOTFS/etc/timezone"
chroot "$NOVA_ROOTFS" /usr/bin/env DEBIAN_FRONTEND=noninteractive apt-get update 2>&1 | tee "$LOG_FILE"
mapfile -t packages < <(grep -Ev '^[[:space:]]*(#|$)' "$NOVA_PROJECT_DIR/config/packages.list")
# Package availability is verified by apt itself; any failure aborts the build.
chroot "$NOVA_ROOTFS" /usr/bin/env DEBIAN_FRONTEND=noninteractive \
  apt-get install -y --no-install-recommends "${packages[@]}" 2>&1 | tee -a "$LOG_FILE"
chroot "$NOVA_ROOTFS" locale-gen en_US.UTF-8 2>&1 | tee -a "$LOG_FILE" || true
if ! chroot "$NOVA_ROOTFS" getent passwd "$NOVA_USER" >/dev/null 2>&1; then
  chroot "$NOVA_ROOTFS" useradd --create-home --shell /bin/bash "$NOVA_USER"
fi
# Lock the account until the operator sets a secure password during device setup.
chroot "$NOVA_ROOTFS" passwd -l "$NOVA_USER"
chroot "$NOVA_ROOTFS" systemctl enable NetworkManager.service
# Enable Phosh only if the installed package provides a service; otherwise desktop session starts via display manager/session configuration.
if chroot "$NOVA_ROOTFS" test -f /usr/lib/systemd/system/phosh.service; then
  chroot "$NOVA_ROOTFS" systemctl enable phosh.service
fi
install -D -m 0644 "$NOVA_PROJECT_DIR/desktop/applications/nova-about.desktop" \
  "$NOVA_ROOTFS/usr/share/applications/nova-about.desktop"
install -D -m 0644 "$NOVA_PROJECT_DIR/apps/nova-about/nova-about.py" \
  "$NOVA_ROOTFS/usr/local/lib/nova/nova-about.py"
install -D -m 0755 "$NOVA_PROJECT_DIR/apps/nova-about/nova-about" \
  "$NOVA_ROOTFS/usr/local/bin/nova-about"
cleanup; trap - EXIT
printf '%s\n' "Configured: ${NOVA_NAME}" "Version: ${NOVA_VERSION}" "Device target: ${DEVICE}" > "$NOVA_OUTPUT_DIR/CONFIG-STATUS.txt"
log "System configuration complete."
