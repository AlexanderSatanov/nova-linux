#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
require_root
command -v debootstrap >/dev/null || die "debootstrap missing; run make deps"
command -v chroot >/dev/null || die "chroot missing"
[[ "$(df -Pk "$NOVA_PROJECT_DIR" | awk 'NR==2 {print $4}')" -gt 6000000 ]] || \
  die "At least about 6 GiB free on the project filesystem is required; 12 GiB recommended."
require_empty_target
mkdir -p "$NOVA_OUTPUT_DIR" "$NOVA_LOG_DIR"
LOG_FILE="$NOVA_LOG_DIR/rootfs.log"
log "Creating Debian ${DEBIAN_SUITE} ${ARCH} root filesystem..."
{
  debootstrap --arch="$ARCH" --foreign "$DEBIAN_SUITE" "$NOVA_ROOTFS" "$DEBIAN_MIRROR"
} 2>&1 | tee "$LOG_FILE"
if [[ "$ARCH" == "arm64" && "$(dpkg --print-architecture)" != "arm64" ]]; then
  command -v qemu-aarch64-static >/dev/null || die "Install qemu-user-static to finish ARM64 bootstrap on a non-ARM64 host."
  install -D -m 0755 "$(command -v qemu-aarch64-static)" "$NOVA_ROOTFS/usr/bin/qemu-aarch64-static"
  # Mount only what is needed, and always unmount on exit.
  mounted=()
  cleanup() {
    for ((i=${#mounted[@]}-1; i>=0; i--)); do umount "${mounted[$i]}" 2>/dev/null || true; done
  }
  trap cleanup EXIT
  mount -t proc proc "$NOVA_ROOTFS/proc"; mounted+=("$NOVA_ROOTFS/proc")
  mount --bind /dev "$NOVA_ROOTFS/dev"; mounted+=("$NOVA_ROOTFS/dev")
  mount --bind /dev/pts "$NOVA_ROOTFS/dev/pts"; mounted+=("$NOVA_ROOTFS/dev/pts")
  mount -t sysfs sysfs "$NOVA_ROOTFS/sys"; mounted+=("$NOVA_ROOTFS/sys")
  chroot "$NOVA_ROOTFS" /debootstrap/debootstrap --second-stage 2>&1 | tee -a "$LOG_FILE"
  cleanup; trap - EXIT
  rm -f "$NOVA_ROOTFS/usr/bin/qemu-aarch64-static"
else
  chroot "$NOVA_ROOTFS" /debootstrap/debootstrap --second-stage 2>&1 | tee -a "$LOG_FILE"
fi
printf '%s\n' "Rootfs created: $NOVA_ROOTFS" | tee "$NOVA_OUTPUT_DIR/ROOTFS-STATUS.txt"
log "Rootfs stage complete."
