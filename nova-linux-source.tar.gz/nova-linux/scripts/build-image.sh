#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
require_root
[[ -d "$NOVA_ROOTFS/etc" ]] || die "Rootfs missing; run make rootfs and make configure."
command -v mke2fs >/dev/null || die "e2fsprogs missing"
IMAGE="$NOVA_OUTPUT_DIR/nova-linux-${ARCH}-rootfs.ext4"
[[ ! -e "$IMAGE" ]] || die "$IMAGE already exists; refusing to overwrite."
mkdir -p "$NOVA_OUTPUT_DIR"
log "Creating ext4 image..."
truncate -s "$ROOTFS_SIZE" "$IMAGE"
if ! mke2fs -t ext4 -F -L NOVA_ROOT -d "$NOVA_ROOTFS" "$IMAGE" 2>&1 | tee "$NOVA_LOG_DIR/image.log"; then
  rm -f "$IMAGE"
  die "Image creation failed; partial image removed."
fi
sha256sum "$IMAGE" > "$IMAGE.sha256"
cat > "$NOVA_OUTPUT_DIR/BUILD-INFO.txt" <<EOF
Project: ${NOVA_NAME}
Version: ${NOVA_VERSION}
Base: Debian ${DEBIAN_SUITE}
Architecture: ${ARCH}
Device target: ${DEVICE}
Artifact: $(basename "$IMAGE")
Artifact type: ext4 root filesystem image
Flashable phone firmware: NO
Kernel/DTB included: NO
EOF
log "Image and SHA-256 manifest created: $IMAGE"
