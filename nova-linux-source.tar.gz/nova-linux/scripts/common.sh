#!/usr/bin/env bash
# Shared functions for Nova Linux build scripts.
set -Eeuo pipefail
NOVA_PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=../config/build.conf
source "$NOVA_PROJECT_DIR/config/build.conf"
NOVA_OUTPUT_DIR="${NOVA_PROJECT_DIR}/${OUTPUT_DIR}"
NOVA_ROOTFS="${NOVA_OUTPUT_DIR}/rootfs"
NOVA_LOG_DIR="${NOVA_OUTPUT_DIR}/logs"
mkdir -p "$NOVA_LOG_DIR"
log() { printf '[Nova Linux] %s\n' "$*"; }
die() { printf '[Nova Linux] ERROR: %s\n' "$*" >&2; exit 1; }
require_root() { [[ "$EUID" -eq 0 ]] || die "Run with sudo for this stage."; }
require_empty_target() {
  [[ ! -e "$NOVA_ROOTFS" ]] || die "$NOVA_ROOTFS already exists; use make clean after inspecting output."
}
