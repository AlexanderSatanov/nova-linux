#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
failed=0
echo "[validate] Bash syntax..."
while IFS= read -r -d '' f; do
  if ! bash -n "$f"; then echo "FAIL syntax: $f"; failed=1; fi
done < <(find scripts tests -type f -name '*.sh' -print0)
if command -v shellcheck >/dev/null; then
  echo "[validate] ShellCheck..."
  shellcheck scripts/*.sh tests/*.sh || failed=1
else
  echo "[validate] SKIP shellcheck not installed"
fi
echo "[validate] Project files..."
for f in README.md LICENSE VERSION Makefile config/build.conf config/packages.list config/device-olive.conf; do
  [[ -s "$f" ]] || { echo "FAIL missing/empty $f"; failed=1; }
done
echo "[validate] Device firmware status..."
echo "INFO: No phone boot image is produced by this project."
exit "$failed"
