#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="$ROOT_DIR/nova-output"
if [[ ! -e "$TARGET" ]]; then echo "Nothing to clean."; exit 0; fi
echo "This will remove only: $TARGET"
read -r -p "Type DELETE-NOVA-OUTPUT to continue: " answer
[[ "$answer" == "DELETE-NOVA-OUTPUT" ]] || { echo "Cancelled."; exit 0; }
case "$TARGET" in "$ROOT_DIR/nova-output") rm -rf -- "$TARGET" ;; *) echo "Unsafe target; aborting." >&2; exit 1 ;; esac
echo "Nova output removed."
