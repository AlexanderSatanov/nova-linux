#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ "${EUID}" -eq 0 ]]; then
  SUDO=()
else
  command -v sudo >/dev/null || { echo "sudo is required"; exit 1; }
  SUDO=(sudo)
fi
if ! command -v apt-get >/dev/null; then
  echo "This dependency helper supports Ubuntu/Debian hosts only." >&2
  exit 1
fi
echo "Installing host build dependencies (Ubuntu/Debian)..."
"${SUDO[@]}" apt-get update
"${SUDO[@]}" apt-get install -y \
  git make debootstrap qemu-user-static binfmt-support e2fsprogs \
  rsync ca-certificates shellcheck python3
echo "Checking tools..."
for tool in git make debootstrap mke2fs truncate sha256sum bash; do
  command -v "$tool" >/dev/null || { echo "Missing tool: $tool" >&2; exit 1; }
done
echo "Dependencies installed."
