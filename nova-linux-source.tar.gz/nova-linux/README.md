# Nova Linux

Nova Linux is a Debian ARM64 mobile Linux development project targeting Xiaomi Redmi 8 (`olive`).
**Current deliverable:** reproducible Debian ARM64 root filesystem and ext4 artifact, plus configuration,
desktop metadata, app prototypes, validation, and device-support documentation.

This is **not yet a flashable Redmi 8 firmware**. A phone boot image needs device-compatible kernel,
DTB, boot/vendor integration, partition layout, and a verified boot chain. The build deliberately
does not unlock, format, or flash a phone.

## Host requirements

Ubuntu/Debian amd64 or arm64 host, internet access, 12+ GiB free disk space recommended.
Building an ARM64 rootfs on amd64 requires `qemu-user-static` and registered binfmt support.

```bash
sudo apt update
sudo apt install -y git make debootstrap qemu-user-static binfmt-support \
  e2fsprogs rsync ca-certificates shellcheck
git clone <your-repository-url> nova-linux
cd nova-linux
make help
make deps
make rootfs
make configure
make image
make test
```

The build uses `sudo` for rootfs/image operations. Outputs are placed in `nova-output/`.
Existing output is not overwritten by default. To start over, inspect the output and then run
`make clean` (interactive confirmation required).

## Build stages

- `make deps`: checks required host packages and tools.
- `make rootfs`: debootstrap Debian Trixie ARM64 rootfs.
- `make configure`: configure hostname, OS identity, APT, users and requested mobile packages.
- `make image`: create a labeled ext4 rootfs image and SHA-256 manifest.
- `make test`: shell syntax, project structure, rootfs and image checks where possible.
- `make clean`: remove only this project's `nova-output` after confirmation.

`Phosh` package availability can vary by Debian suite and architecture. A package install failure is
reported as a failure, not silently presented as success. No phone boot image is produced.

## Current limitations

- No custom Linux kernel is built by this project yet.
- The device-specific `olive` kernel, DTB and Android boot image integration must be validated separately.
- Phone functions (cellular modem, cameras, audio, Bluetooth, suspend, charging) are not guaranteed.
- The sample Python/GTK apps are minimal source examples, not complete system settings replacements.
- Never flash the ext4 rootfs directly to a phone partition.
