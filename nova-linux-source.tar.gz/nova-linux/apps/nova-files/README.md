# Nova Files

A full file manager is not implemented in this milestone. Use the installed desktop's
file manager until a GTK4/GIO application is added. Any future implementation must use
GIO operations, handle permission errors, confirm deletes, and never run as root.
