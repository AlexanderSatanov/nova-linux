# Nova Settings (planned integration)

This directory documents the initial settings app scope. No fake controls are shipped.
A real settings application should use NetworkManager's D-Bus API for networking,
BlueZ only when available, UPower for battery, and system settings services appropriate
to the installed Phosh/GNOME stack. Implement one feature at a time and expose unsupported
hardware as unavailable rather than showing a non-functional switch.
