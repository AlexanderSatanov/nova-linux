# Nova About

A small GTK4 application showing OS identity, kernel release, architecture, and target-device
status. Device target is not proof that the app is running on a Redmi 8.
