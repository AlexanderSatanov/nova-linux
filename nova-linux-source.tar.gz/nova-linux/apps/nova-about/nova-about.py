#!/usr/bin/env python3
"""Minimal GTK4 information screen for Nova Linux."""
import os
import platform
import subprocess

def read_os_release():
    data = {}
    try:
        with open("/etc/os-release", encoding="utf-8") as stream:
            for line in stream:
                if "=" in line:
                    key, value = line.rstrip().split("=", 1)
                    data[key] = value.strip('"')
    except OSError:
        pass
    return data

def main():
    try:
        import gi
        gi.require_version("Gtk", "4.0")
        from gi.repository import Gtk
    except Exception as exc:
        print(f"GTK4 unavailable: {exc}")
        print("Nova Linux - system information")
        print(f"Kernel: {platform.release()}")
        print(f"Architecture: {platform.machine()}")
        return 0

    info = read_os_release()
    app = Gtk.Application(application_id="org.novalinux.About")
    def on_activate(application):
        window = Gtk.ApplicationWindow(application=application)
        window.set_title("About Nova Linux")
        window.set_default_size(360, 480)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.set_margin_top(24); box.set_margin_bottom(24)
        box.set_margin_start(20); box.set_margin_end(20)
        title = Gtk.Label(label=info.get("PRETTY_NAME", "Nova Linux"))
        title.add_css_class("title-1")
        box.append(title)
        rows = [
            ("Version", info.get("VERSION_ID", "unknown")),
            ("Kernel", platform.release()),
            ("Architecture", platform.machine()),
            ("Device target", "Xiaomi Redmi 8 (olive; target only)"),
            ("Status", "Developer preview; hardware support unverified"),
        ]
        for key, value in rows:
            label = Gtk.Label(label=f"{key}: {value}", xalign=0)
            label.set_wrap(True)
            box.append(label)
        window.set_child(box)
        window.present()
    app.connect("activate", on_activate)
    return app.run(None)

if __name__ == "__main__":
    raise SystemExit(main())
