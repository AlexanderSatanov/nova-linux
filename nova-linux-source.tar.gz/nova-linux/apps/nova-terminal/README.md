# Nova Terminal

A terminal emulator is not implemented in this milestone. Use a maintained terminal
emulator compatible with the selected Phosh environment. Do not embed a shell in a
privileged app; commands must run as the logged-in user.
