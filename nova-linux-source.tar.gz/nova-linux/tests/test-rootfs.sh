#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT_DIR/nova-output"
if [[ ! -d "$OUT/rootfs" ]]; then
  echo "SKIP: rootfs not built yet."
  exit 0
fi
for f in etc/os-release etc/hostname etc/apt/sources.list; do
  [[ -s "$OUT/rootfs/$f" ]] || { echo "FAIL: missing $f"; exit 1; }
done
if [[ -f "$OUT/nova-linux-arm64-rootfs.ext4" ]]; then
  command -v file >/dev/null && file "$OUT/nova-linux-arm64-rootfs.ext4" || true
  [[ -s "$OUT/nova-linux-arm64-rootfs.ext4.sha256" ]] || {
    echo "FAIL: missing checksum"; exit 1;
  }
fi
echo "PASS: rootfs structure checks"
