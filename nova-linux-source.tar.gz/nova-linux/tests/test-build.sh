#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
for f in scripts/*.sh; do bash -n "$f"; done
[[ -s config/build.conf ]]
[[ -s config/packages.list ]]
[[ -s device/xiaomi/olive/README.md ]]
echo "PASS: project structure and shell syntax"
