# Recovery and rollback

Before testing on hardware, establish a model-specific recovery path and obtain stock firmware
from a trusted source. Back up user data. This project does not unlock the bootloader, alter
partitions, or flash the phone automatically.
