# Kernel integration checkpoint

No kernel source is vendored in this repository. Use a verified upstream/downstream source for
the exact `olive` device and pin it to a commit. Do not assume a generic Debian kernel can boot
on the phone. Document required config fragments, compiler version, DTB name, boot image format,
vendor dependencies, license, and test evidence before enabling any image packaging.
