# Xiaomi Redmi 8 (`olive`) device support

Target: Xiaomi Redmi 8, Qualcomm Snapdragon 439, ARM64.

This folder intentionally does not contain fabricated kernel patches, DTBs, boot images,
or claims of hardware support. Start with the current postmarketOS device page and upstream
source repositories. Record exact upstream commit IDs, licensing, build configuration, and
test evidence before importing anything.

## Required investigations

1. Verify exact model and codename (`olive`, not Redmi 8A `olivelite`).
2. Inspect current postmarketOS device package and kernel package sources.
3. Identify the bootloader's expected Android boot image format and partition layout.
4. Verify whether a compatible downstream kernel and DTB exist for this exact device.
5. Determine required firmware blobs and redistribution/licensing constraints.
6. Test only on a device with a verified recovery path and after data backup.

Never flash the ext4 rootfs image directly to a phone partition.
