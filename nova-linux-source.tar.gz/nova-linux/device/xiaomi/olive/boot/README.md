# Boot image integration checkpoint

No boot image is generated yet. Packaging requires a compatible kernel, device tree, initramfs
or rootfs handoff, verified partition map, and correct Android boot image format. Keep this stage
disabled until these inputs are sourced and validated. Never write directly to a physical device
from the default build target.
